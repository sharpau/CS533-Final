CS533 Final Project
Austin Sharp
Rich Meier

'python ./CS533_Final.py' runs our experiment. Change experiment parameters by editing the lists named 'policies', 'budgets', 'c_vals', 'opponents' and the variable 'n' near the bottom of CS533_Final.py. Be warned, this takes a significant amount of time to run, especially for budgets > 1 second (thus the relatively sparse current parameters).

'python ./othello_gui.py' opens a GUI for a user to play against our agent. The agent's thinking time per move, default policy and c-value may be changed at the bottom of this file to play against variations of the UCT algorithm.

To change the board size from 6 to another even number, change the variable 'size' at the top of othello.py.

